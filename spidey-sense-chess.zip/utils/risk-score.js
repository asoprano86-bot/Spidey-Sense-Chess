/**
 * Spidey Sense Chess - Risk Score Calculation
 * Core algorithm for detecting potential cheating
 */

import { 
    THRESHOLDS, 
    WEIGHTS, 
    WINRATE_THRESHOLDS, 
    HIGH_ACCURACY_THRESHOLDS,
    RISK_LEVELS 
} from '../config.js';

// Cache for weight calculations
const weightCache = new Map();

/**
 * Calculate weight based on sample size
 * More games = more confidence = higher weight
 * @param {number} n - Number of samples
 * @returns {number} Weight between 0 and 1
 */
function calculateWeight(n) {
    if (weightCache.has(n)) return weightCache.get(n);
    
    const weight = n / (n + THRESHOLDS.WEIGHTING_K);
    weightCache.set(n, weight);
    return weight;
}

/**
 * Calculate win rate score
 * Higher win rates = higher risk score
 * @param {number} winRate - Win rate as decimal (0-1)
 * @param {number} totalGames - Total games played
 * @returns {number} Score (can exceed 100 for extreme cases)
 */
function calculateWinRateScore(winRate, totalGames) {
    let score = 0;
    
    if (winRate <= WINRATE_THRESHOLDS.LOW_WINRATE_THRESHOLD) {
        return 0; // 50% or below is normal
    }
    
    if (winRate > WINRATE_THRESHOLDS.HIGH_WINRATE_THRESHOLD) {
        // Above 70% - very suspicious
        score = WINRATE_THRESHOLDS.EXTENDED_SCORE + 
                ((winRate - WINRATE_THRESHOLDS.HIGH_WINRATE_THRESHOLD) / WINRATE_THRESHOLDS.SCALE_FACTOR) * 
                WINRATE_THRESHOLDS.EXTENDED_SCORE;
    } else if (winRate > WINRATE_THRESHOLDS.MEDIUM_WINRATE_THRESHOLD) {
        // 60-70% - suspicious
        score = WINRATE_THRESHOLDS.BASE_SCORE + 
                ((winRate - WINRATE_THRESHOLDS.MEDIUM_WINRATE_THRESHOLD) / 
                (WINRATE_THRESHOLDS.HIGH_WINRATE_THRESHOLD - WINRATE_THRESHOLDS.MEDIUM_WINRATE_THRESHOLD)) * 
                WINRATE_THRESHOLDS.BASE_SCORE;
    } else {
        // 50-60% - slightly elevated
        score = ((winRate - WINRATE_THRESHOLDS.LOW_WINRATE_THRESHOLD) / 
                (WINRATE_THRESHOLDS.MEDIUM_WINRATE_THRESHOLD - WINRATE_THRESHOLDS.LOW_WINRATE_THRESHOLD)) * 
                WINRATE_THRESHOLDS.BASE_SCORE;
    }
    
    return score * calculateWeight(totalGames);
}

/**
 * Calculate high accuracy games score
 * Players with many "perfect" games are suspicious
 * @param {Object} accuracyData - Accuracy metrics
 * @returns {Object} Score and debug info
 */
function calculateHighAccuracyScore(accuracyData) {
    const { gamesWithAccuracy, highAccuracyPercentage } = accuracyData;

    if (gamesWithAccuracy === 0 || isNaN(highAccuracyPercentage)) {
        return {
            score: 0,
            debug: { reason: 'no_accuracy_data' }
        };
    }

    // No risk if low percentage of high-accuracy games
    if (highAccuracyPercentage <= HIGH_ACCURACY_THRESHOLDS.MODERATE_SUSPICION_THRESHOLD) {
        return {
            score: 0,
            debug: { reason: 'low_accuracy_percentage' }
        };
    }

    const sampleWeight = calculateWeight(gamesWithAccuracy);
    let baseScore;

    if (highAccuracyPercentage > HIGH_ACCURACY_THRESHOLDS.EXTREME_SUSPICION_THRESHOLD) {
        // Above 30% - extremely suspicious
        baseScore = HIGH_ACCURACY_THRESHOLDS.HIGH_MAX_SCORE + 
            Math.floor((highAccuracyPercentage - HIGH_ACCURACY_THRESHOLDS.EXTREME_SUSPICION_THRESHOLD) / 
            HIGH_ACCURACY_THRESHOLDS.EXTREME_SCORE_STEP) * 
            HIGH_ACCURACY_THRESHOLDS.EXTREME_SCORE_INCREMENT;
    } else if (highAccuracyPercentage > HIGH_ACCURACY_THRESHOLDS.HIGH_SUSPICION_THRESHOLD) {
        // 20-30% - highly suspicious
        const progressInRange = (highAccuracyPercentage - HIGH_ACCURACY_THRESHOLDS.HIGH_SUSPICION_THRESHOLD) / 
            (HIGH_ACCURACY_THRESHOLDS.EXTREME_SUSPICION_THRESHOLD - HIGH_ACCURACY_THRESHOLDS.HIGH_SUSPICION_THRESHOLD);
        baseScore = HIGH_ACCURACY_THRESHOLDS.MODERATE_MAX_SCORE + 
            progressInRange * HIGH_ACCURACY_THRESHOLDS.MODERATE_MAX_SCORE;
    } else {
        // 10-20% - moderately suspicious
        const progressInRange = (highAccuracyPercentage - HIGH_ACCURACY_THRESHOLDS.MODERATE_SUSPICION_THRESHOLD) / 
            (HIGH_ACCURACY_THRESHOLDS.HIGH_SUSPICION_THRESHOLD - HIGH_ACCURACY_THRESHOLDS.MODERATE_SUSPICION_THRESHOLD);
        baseScore = progressInRange * HIGH_ACCURACY_THRESHOLDS.MODERATE_MAX_SCORE;
    }

    return {
        score: baseScore * sampleWeight,
        debug: { baseScore, sampleWeight }
    };
}

/**
 * Calculate account age factor
 * New accounts with high performance are more suspicious
 * @param {number} accountAgeDays - Account age in days
 * @returns {number} Multiplier (1 or 1.5)
 */
function calculateAccountAgeFactor(accountAgeDays) {
    return accountAgeDays <= THRESHOLDS.ACCOUNT_AGE_DAYS 
        ? THRESHOLDS.ACCOUNT_AGE_MULTIPLIER 
        : 1;
}

/**
 * Calculate risk score for a specific format
 * @param {Object} formatMetrics - Metrics for the format
 * @returns {Object} Risk score and breakdown
 */
function calculateFormatRiskScore(formatMetrics) {
    const {
        overallWinrate,
        gamesCounts,
        recentGames,
        accuracy
    } = formatMetrics;

    // Calculate individual component scores
    const overallWinRateScore = calculateWinRateScore(
        overallWinrate / 100,
        gamesCounts.total
    );

    const recentWinRateScore = calculateWinRateScore(
        recentGames.winrate / 100,
        recentGames.total
    );

    const accuracyResult = calculateHighAccuracyScore(accuracy);
    const highAccuracyScore = accuracyResult.score;

    // Calculate weighted sum
    const weightedSum = (
        WEIGHTS.OVERALL_WINRATE * overallWinRateScore +
        WEIGHTS.RECENT_WINRATE * recentWinRateScore +
        WEIGHTS.HIGH_ACCURACY * highAccuracyScore
    );

    return {
        score: weightedSum,
        breakdown: {
            overallWinRate: {
                raw: overallWinrate,
                score: overallWinRateScore,
                weight: WEIGHTS.OVERALL_WINRATE,
                weighted: WEIGHTS.OVERALL_WINRATE * overallWinRateScore,
                games: gamesCounts.total
            },
            recentWinRate: {
                raw: recentGames.winrate,
                score: recentWinRateScore,
                weight: WEIGHTS.RECENT_WINRATE,
                weighted: WEIGHTS.RECENT_WINRATE * recentWinRateScore,
                games: recentGames.total
            },
            accuracy: {
                raw: accuracy.highAccuracyPercentage,
                score: accuracyResult.score,
                weight: WEIGHTS.HIGH_ACCURACY,
                weighted: WEIGHTS.HIGH_ACCURACY * accuracyResult.score,
                gamesWithAccuracy: accuracy.gamesWithAccuracy,
                highAccuracyGames: accuracy.highAccuracyGames,
                ...accuracyResult.debug
            }
        }
    };
}

/**
 * Calculate final risk score for a player
 * @param {Object} metrics - Player metrics
 * @returns {Object} Risk score results
 */
export function calculateRiskScore(metrics) {
    const accountAgeFactor = calculateAccountAgeFactor(metrics.accountAge);
    
    const formatScores = [];
    
    // Calculate score for each format
    for (const [format, formatMetrics] of Object.entries(metrics.formats)) {
        if (formatMetrics.recentGames.total < THRESHOLDS.MIN_GAMES) continue;

        const result = calculateFormatRiskScore(formatMetrics);
        const finalScore = Math.min(100, accountAgeFactor * result.score);
        
        formatScores.push({
            format,
            score: finalScore,
            breakdown: {
                ...result.breakdown,
                accountAgeFactor,
                calculation: {
                    weightedSum: result.score,
                    accountAgeFactor,
                    beforeCap: accountAgeFactor * result.score,
                    afterCap: finalScore
                }
            }
        });
    }

    // No valid formats
    if (formatScores.length === 0) {
        return {
            maxScore: {
                value: 0,
                format: null,
                breakdown: null,
                reason: 'insufficient_games'
            },
            otherFormats: [],
            accountAge: metrics.accountAge,
            accountAgeFactor,
            riskLevel: RISK_LEVELS.LOW,
            timestamp: new Date().toISOString()
        };
    }

    // Sort by score descending
    formatScores.sort((a, b) => b.score - a.score);
    
    const highest = formatScores[0];
    const otherFormats = formatScores.slice(1);

    // Determine risk level
    let riskLevel;
    if (highest.score <= RISK_LEVELS.LOW.max) {
        riskLevel = RISK_LEVELS.LOW;
    } else if (highest.score <= RISK_LEVELS.MEDIUM.max) {
        riskLevel = RISK_LEVELS.MEDIUM;
    } else {
        riskLevel = RISK_LEVELS.HIGH;
    }

    return {
        maxScore: {
            value: highest.score,
            format: highest.format,
            breakdown: highest.breakdown
        },
        otherFormats: otherFormats,
        accountAge: metrics.accountAge,
        accountAgeFactor,
        riskLevel,
        timestamp: new Date().toISOString()
    };
}

/**
 * Calculate risk score from username
 * @param {string} username - Chess.com username
 * @param {Object} playerData - Pre-fetched player data (optional)
 * @returns {Promise<Object>} Risk score results
 */
export async function calculateRiskScoreFromUsername(username, playerData = null) {
    // If playerData not provided, we need to import and gather it
    // This will be called from background script which has access to utils
    if (!playerData) {
        throw new Error('playerData must be provided');
    }
    
    const metrics = calculatePlayerMetrics(playerData);
    return calculateRiskScore(metrics);
}

// Import metrics calculation
import { calculatePlayerMetrics } from './metrics-utils.js';
