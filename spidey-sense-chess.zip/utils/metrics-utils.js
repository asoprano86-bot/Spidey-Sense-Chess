/**
 * Spidey Sense Chess - Metrics Calculation
 * Calculate player metrics from API data
 */

import { ACCURACY_THRESHOLDS } from '../config.js';

/**
 * Calculate account age in days
 * @param {number} joinedTimestamp - Unix timestamp of account creation
 * @returns {number} Account age in days
 */
export function calculateAccountAge(joinedTimestamp) {
    const now = Date.now();
    const joinedDate = new Date(joinedTimestamp * 1000);
    return Math.floor((now - joinedDate) / (1000 * 60 * 60 * 24));
}

/**
 * Calculate winrate from record
 * @param {Object} record - Win/loss/draw counts
 * @returns {number} Winrate percentage
 */
export function calculateWinrate(record) {
    const { wins = 0, losses = 0, draws = 0 } = record;
    const total = wins + losses + draws;
    return total > 0 ? ((wins / total) * 100) : 0;
}

/**
 * Check if accuracy is considered high based on rating
 * @param {number} accuracy - Game accuracy percentage
 * @param {number} rating - Player rating
 * @returns {boolean} Whether accuracy is high
 */
export function isHighAccuracy(accuracy, rating) {
    if (!accuracy || isNaN(accuracy)) return false;
    const threshold = rating < ACCURACY_THRESHOLDS.LOW_RATING.threshold
        ? ACCURACY_THRESHOLDS.LOW_RATING.requiredAccuracy
        : ACCURACY_THRESHOLDS.HIGH_RATING.requiredAccuracy;
    return accuracy >= threshold;
}

/**
 * Calculate metrics for a specific game format
 * @param {Object} stats - Stats for the format
 * @param {Array} recentGames - All recent games
 * @returns {Object} Format metrics
 */
export function calculateFormatMetrics(stats, recentGames) {
    const formatGames = recentGames.filter(game => 
        game.timeClass === stats.timeClass
    );
    
    // Count recent game results
    const recentStats = formatGames.reduce((acc, game) => {
        switch (game.result) {
            case 'win': acc.wins++; break;
            case 'loss': acc.losses++; break;
            case 'draw': acc.draws++; break;
        }
        return acc;
    }, { wins: 0, losses: 0, draws: 0 });

    // Calculate accuracy metrics
    const gamesWithAccuracy = formatGames.filter(game => 
        game.accuracy != null && !isNaN(game.accuracy)
    );
    
    const highAccuracyGames = gamesWithAccuracy.filter(game => 
        isHighAccuracy(game.accuracy, game.playerRating)
    );

    return {
        currentRating: stats.rating || 0,
        bestRating: stats.best || 0,
        overallWinrate: calculateWinrate({
            wins: stats.wins,
            losses: stats.losses,
            draws: stats.draws
        }),
        gamesCounts: {
            total: stats.wins + stats.losses + stats.draws,
            wins: stats.wins,
            losses: stats.losses,
            draws: stats.draws
        },
        recentGames: {
            total: recentStats.wins + recentStats.losses + recentStats.draws,
            wins: recentStats.wins,
            losses: recentStats.losses,
            draws: recentStats.draws,
            winrate: calculateWinrate(recentStats)
        },
        accuracy: {
            gamesWithAccuracy: gamesWithAccuracy.length,
            highAccuracyGames: highAccuracyGames.length,
            highAccuracyPercentage: gamesWithAccuracy.length > 0 
                ? (highAccuracyGames.length / gamesWithAccuracy.length) * 100 
                : 0,
            avgAccuracy: gamesWithAccuracy.length > 0
                ? gamesWithAccuracy.reduce((sum, g) => sum + g.accuracy, 0) / gamesWithAccuracy.length
                : 0
        }
    };
}

/**
 * Calculate all metrics for a player
 * @param {Object} playerData - Combined player data
 * @returns {Object} All calculated metrics
 */
export function calculatePlayerMetrics(playerData) {
    const { profile, stats, recentGames } = playerData;

    // Calculate account age
    const accountAge = calculateAccountAge(profile.joined);

    // Calculate metrics for each format
    const formats = ['chess_rapid', 'chess_bullet', 'chess_blitz'];
    const formatMetrics = {};

    formats.forEach(format => {
        if (stats[format]) {
            formatMetrics[format] = calculateFormatMetrics(stats[format], recentGames);
        }
    });

    return {
        accountAge,
        accountJoined: profile.joinedDate,
        username: profile.username,
        formats: formatMetrics,
        timestamp: new Date().toISOString()
    };
}
