/**
 * Spidey Sense Chess - Utility Functions
 * Chess.com API interactions with retry logic
 */

import { GAME_RESULTS, DEFAULT_SETTINGS } from './config.js';

const API_BASE_URL = 'https://api.chess.com/pub';

/**
 * Fetch with retry and exponential backoff
 * @param {string} url - URL to fetch
 * @param {Object} options - Fetch options
 * @param {number} maxRetries - Maximum retries (default: 3)
 * @param {number} baseDelay - Base delay in ms (default: 1000)
 * @returns {Promise<Response>} Fetch response
 */
export async function fetchWithRetry(url, options = {}, maxRetries = 3, baseDelay = 1000) {
    let lastError;
    
    for (let attempt = 0; attempt <= maxRetries; attempt++) {
        try {
            const response = await fetch(url, options);
            
            // Only retry on server errors (5xx) or rate limits (429)
            if (response.status >= 500 || response.status === 429) {
                throw new Error(`Retryable error: ${response.status}`);
            }
            
            return response;
        } catch (error) {
            lastError = error;
            
            // Only retry on network errors or retryable status codes
            if (!error.message.includes('Retryable error') && !error.message.includes('Failed to fetch')) {
                throw error;
            }
            
            if (attempt === maxRetries) break;
            
            const delay = baseDelay * Math.pow(2, attempt);
            console.log(`[SpideySense] Retry ${attempt + 1}/${maxRetries} after ${delay}ms`);
            await new Promise(resolve => setTimeout(resolve, delay));
        }
    }
    
    throw lastError;
}

/**
 * Fetches player profile
 * @param {string} username - Chess.com username
 * @returns {Promise<Object>} Player profile data
 */
export async function fetchPlayerProfile(username) {
    try {
        const response = await fetchWithRetry(`${API_BASE_URL}/player/${username}`);
        if (!response.ok) throw new Error(`Profile fetch failed: ${response.status}`);
        const data = await response.json();
        
        if (!data || typeof data.joined !== 'number') {
            throw new Error('Invalid profile data');
        }
        
        return {
            joined: data.joined,
            username: data.username,
            status: data.status,
            joinedDate: new Date(data.joined * 1000)
        };
    } catch (error) {
        console.error('[SpideySense] Error fetching player profile:', error);
        throw error;
    }
}

/**
 * Fetches player statistics
 * @param {string} username - Chess.com username
 * @returns {Promise<Object>} Player statistics
 */
export async function fetchPlayerStats(username) {
    try {
        const response = await fetchWithRetry(`${API_BASE_URL}/player/${username}/stats`);
        if (!response.ok) throw new Error(`Stats fetch failed: ${response.status}`);
        const data = await response.json();

        const relevantFormats = ['chess_rapid', 'chess_bullet', 'chess_blitz'];
        const stats = {};

        relevantFormats.forEach(format => {
            if (data[format]) {
                stats[format] = {
                    rating: data[format].last?.rating || 0,
                    best: data[format].best?.rating || 0,
                    wins: data[format].record?.win || 0,
                    losses: data[format].record?.loss || 0,
                    draws: data[format].record?.draw || 0,
                    timeClass: format.replace('chess_', '')
                };
            }
        });

        return stats;
    } catch (error) {
        console.error('[SpideySense] Error fetching player stats:', error);
        throw error;
    }
}

/**
 * Fetches recent games for a player
 * @param {string} username - Chess.com username
 * @param {boolean} ratedOnly - Only fetch rated games
 * @returns {Promise<Array>} Recent games data
 */
export async function fetchRecentGames(username, ratedOnly = true) {
    try {
        const date = new Date();
        const currentYear = date.getFullYear();
        const currentMonth = date.getMonth() + 1;
        
        // Fetch current and previous month to get recent games
        const monthsToFetch = [];
        
        // Always fetch current month
        monthsToFetch.push({ 
            year: currentYear, 
            month: String(currentMonth).padStart(2, '0') 
        });
        
        // If early in month, also fetch previous month
        if (date.getDate() < 15) {
            const prevDate = new Date(currentYear, currentMonth - 2, 1);
            monthsToFetch.push({
                year: prevDate.getFullYear(),
                month: String(prevDate.getMonth() + 1).padStart(2, '0')
            });
        }

        const gamesPromises = monthsToFetch.map(({ year, month }) =>
            fetchWithRetry(`${API_BASE_URL}/player/${username}/games/${year}/${month}`)
                .then(response => response.json())
                .catch(err => {
                    console.warn(`[SpideySense] Failed to fetch games for ${year}/${month}:`, err.message);
                    return { games: [] };
                })
        );

        const responses = await Promise.all(gamesPromises);
        
        const games = responses
            .flatMap(response => response.games || [])
            .filter(game => 
                game?.rules === 'chess' && 
                ['rapid', 'bullet', 'blitz'].includes(game?.time_class) &&
                (!ratedOnly || game?.rated === true)
            )
            .map(game => {
                const playerColor = game.white.username.toLowerCase() === username.toLowerCase() ? 'white' : 'black';
                const rawResult = game[playerColor].result;
                
                return {
                    timeClass: game.time_class,
                    playerColor,
                    playerRating: game[playerColor].rating,
                    opponentRating: game[playerColor === 'white' ? 'black' : 'white'].rating,
                    result: GAME_RESULTS[rawResult] || 'unknown',
                    accuracy: game.accuracies?.[playerColor],
                    opponentAccuracy: game.accuracies?.[playerColor === 'white' ? 'black' : 'white'],
                    timestamp: game.end_time,
                    rated: game.rated,
                    url: game.url
                };
            })
            .filter(game => game.result !== 'unknown');

        return games;
    } catch (error) {
        console.error('[SpideySense] Error fetching recent games:', error);
        throw error;
    }
}

/**
 * Gather all player data in parallel
 * @param {string} username - Chess.com username
 * @param {boolean} ratedOnly - Only analyze rated games
 * @returns {Promise<Object>} Combined player data
 */
export async function gatherPlayerData(username, ratedOnly = true) {
    try {
        console.log(`[SpideySense] Gathering data for: ${username}`);
        
        const [profile, stats, recentGames] = await Promise.all([
            fetchPlayerProfile(username),
            fetchPlayerStats(username),
            fetchRecentGames(username, ratedOnly)
        ]);

        console.log(`[SpideySense] Data gathered: ${recentGames.length} recent games`);

        return {
            profile,
            stats,
            recentGames
        };
    } catch (error) {
        console.error('[SpideySense] Error gathering player data:', error);
        throw error;
    }
}
