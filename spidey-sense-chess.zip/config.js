/**
 * Spidey Sense Chess - Configuration
 * Spider-Man themed chess anti-cheat extension
 */

export const GAME_RESULTS = {
    // Wins
    'win': 'win',
    
    // Draws
    'agreed': 'draw',
    'repetition': 'draw',
    'stalemate': 'draw',
    'insufficient': 'draw',
    '50move': 'draw',
    
    // Losses
    'checkmated': 'loss',
    'timeout': 'loss',
    'resigned': 'loss',
    'lose': 'loss',
    'abandoned': 'loss'
};

export const GAME_FORMATS = ['chess_rapid', 'chess_bullet', 'chess_blitz'];

export const FORMAT_NAMES = {
    'chess_bullet': 'Bullet',
    'chess_blitz': 'Blitz',
    'chess_rapid': 'Rapid'
};

// Risk score weights - how much each factor contributes
export const WEIGHTS = {
    OVERALL_WINRATE: 0.30,
    RECENT_WINRATE: 0.35,
    HIGH_ACCURACY: 0.35
};

// Thresholds for risk calculations
export const THRESHOLDS = {
    ACCOUNT_AGE_DAYS: 90,           // Accounts newer than this get higher risk
    ACCOUNT_AGE_MULTIPLIER: 1.5,    // Multiplier for new accounts
    WEIGHTING_K: 20,                // Sample size weighting constant
    MIN_GAMES: 5,                   // Minimum games required for analysis
    MIN_RECENT_GAMES: 3             // Minimum recent games for recent winrate
};

// Win rate scoring thresholds
export const WINRATE_THRESHOLDS = {
    LOW_WINRATE_THRESHOLD: 0.50,      // 50% - baseline
    MEDIUM_WINRATE_THRESHOLD: 0.60,   // 60% - starting to raise flags
    HIGH_WINRATE_THRESHOLD: 0.70,     // 70% - very suspicious
    EXTENDED_SCORE: 100,              // Max base score
    BASE_SCORE: 50,                   // Base score for scaling
    SCALE_FACTOR: 0.1,                // Scale factor for calculations
    SIGNIFICANT_DIFF: 0.15,           // 15% difference between recent/overall is significant
    MAX_SCORE: 100,                   // Maximum score
    COMBINED_WEIGHT_FACTOR: 2         // Combined weight calculation factor
};

// High accuracy game detection thresholds
// Players with many games at 90%+ accuracy (or 80%+ for <1500 rating) are suspicious
export const HIGH_ACCURACY_THRESHOLDS = {
    MODERATE_SUSPICION_THRESHOLD: 10,   // Start scoring at 10% high-accuracy games
    HIGH_SUSPICION_THRESHOLD: 20,       // 20% is highly suspicious
    EXTREME_SUSPICION_THRESHOLD: 30,    // 30%+ is extremely suspicious (likely cheating)
    
    // Score scaling
    MODERATE_MAX_SCORE: 50,             // Max score for moderate range
    HIGH_MAX_SCORE: 100,                // Max score for high range
    EXTREME_SCORE_INCREMENT: 50,        // Additional score per step above 30%
    EXTREME_SCORE_STEP: 5               // Step size for extreme calculations
};

// Accuracy thresholds based on rating
export const ACCURACY_THRESHOLDS = {
    LOW_RATING: {
        threshold: 1500,
        requiredAccuracy: 80  // 80%+ is high accuracy for <1500
    },
    HIGH_RATING: {
        threshold: 1500,
        requiredAccuracy: 90  // 90%+ is high accuracy for 1500+
    }
};

// Default settings
export const DEFAULT_SETTINGS = {
    RATED_ONLY: true,           // Only analyze rated games
    AUTO_OPEN_POPUP: false,     // Auto-open popup on opponent detection
    SHOW_BADGE: true,           // Show badge notification
    DEBUG_MODE: false           // Enable debug logging
};

// Risk level thresholds for display
export const RISK_LEVELS = {
    LOW: { max: 33, color: '#22c55e', label: 'Low Risk' },      // Green
    MEDIUM: { max: 66, color: '#f59e0b', label: 'Medium Risk' }, // Orange
    HIGH: { max: 100, color: '#ef4444', label: 'High Risk' }     // Red
};
