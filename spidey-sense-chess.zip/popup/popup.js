/**
 * Spidey Sense Chess - Popup Script
 * Displays risk score and breakdown
 */

import { FORMAT_NAMES, RISK_LEVELS } from '../config.js';

class SpideySensePopup {
    constructor() {
        this.port = null;
        this.elements = {
            loading: document.getElementById('loading'),
            error: document.getElementById('error'),
            errorMessage: document.getElementById('error-message'),
            noData: document.getElementById('no-data'),
            riskDisplay: document.getElementById('risk-display'),
            opponentName: document.getElementById('opponent-name'),
            riskScoreValue: document.getElementById('risk-score-value'),
            riskScoreLabel: document.getElementById('risk-score-label'),
            riskScoreContainer: document.getElementById('risk-score-container'),
            riskBar: document.getElementById('risk-bar'),
            formatBadge: document.getElementById('format-badge'),
            overallWinrate: document.getElementById('overall-winrate'),
            recentWinrate: document.getElementById('recent-winrate'),
            highAccuracy: document.getElementById('high-accuracy'),
            accountAge: document.getElementById('account-age'),
            settingsLink: document.getElementById('settings-link')
        };

        this.setupConnection();
        this.setupEventListeners();
        this.showLoading();
    }

    setupConnection() {
        try {
            this.port = chrome.runtime.connect({ name: 'popup' });
            console.log('[Popup] Connected to background script');

            this.port.onMessage.addListener((message) => {
                console.log('[Popup] Message received:', message);
                this.handleMessage(message);
            });

            this.port.onDisconnect.addListener(() => {
                console.log('[Popup] Disconnected from background');
                this.port = null;
            });

            // Request current state
            this.port.postMessage({ action: 'getCurrentState' });

        } catch (error) {
            console.error('[Popup] Connection failed:', error);
            this.showError('Failed to connect to Spidey Sense');
        }
    }

    setupEventListeners() {
        this.elements.settingsLink.addEventListener('click', (e) => {
            e.preventDefault();
            chrome.runtime.openOptionsPage();
        });
    }

    handleMessage(message) {
        switch (message.action) {
            case 'updateRiskScore':
                if (message.data) {
                    this.updateDisplay(message.data);
                } else {
                    this.showLoading();
                }
                break;

            case 'calculatingRiskScore':
                this.showLoading();
                break;

            case 'opponentPending':
                this.showLoading('Detecting opponent...');
                break;

            case 'clearDisplay':
                this.showNoData();
                break;

            case 'error':
                this.showError(message.message || 'Unknown error');
                break;

            default:
                console.warn('[Popup] Unknown message:', message.action);
        }
    }

    showLoading(text = 'Analyzing opponent...') {
        this.hideAll();
        this.elements.loading.style.display = 'flex';
        this.elements.loading.querySelector('.loading-text').textContent = text;
    }

    showError(message) {
        this.hideAll();
        this.elements.error.style.display = 'block';
        this.elements.errorMessage.textContent = message;
    }

    showNoData() {
        this.hideAll();
        this.elements.noData.style.display = 'block';
    }

    hideAll() {
        this.elements.loading.style.display = 'none';
        this.elements.error.style.display = 'none';
        this.elements.noData.style.display = 'none';
        this.elements.riskDisplay.classList.remove('active');
    }

    updateDisplay(data) {
        if (!data || !data.maxScore) {
            this.showNoData();
            return;
        }

        this.hideAll();
        this.elements.riskDisplay.classList.add('active');

        // Opponent name
        this.elements.opponentName.textContent = data.opponentUsername || 'Unknown';

        // Risk score
        const score = Math.round(data.maxScore.value);
        const riskLevel = data.riskLevel || this.getRiskLevel(score);

        this.elements.riskScoreValue.textContent = `${score}%`;
        this.elements.riskScoreLabel.textContent = riskLevel.label;
        this.elements.riskScoreLabel.style.color = riskLevel.color;
        this.elements.riskScoreContainer.style.borderColor = riskLevel.color;

        // Risk bar
        this.elements.riskBar.style.width = `${score}%`;
        this.elements.riskBar.style.backgroundColor = riskLevel.color;

        // Format badge
        if (data.maxScore.format) {
            const formatName = FORMAT_NAMES[data.maxScore.format] || data.maxScore.format;
            this.elements.formatBadge.textContent = formatName;
            this.elements.formatBadge.style.display = 'inline-block';
        } else {
            this.elements.formatBadge.style.display = 'none';
        }

        // Breakdown
        if (data.maxScore.breakdown) {
            const breakdown = data.maxScore.breakdown;

            // Overall win rate
            if (breakdown.overallWinRate) {
                this.elements.overallWinrate.textContent = 
                    `${breakdown.overallWinRate.raw.toFixed(1)}% (${breakdown.overallWinRate.games} games)`;
            }

            // Recent win rate
            if (breakdown.recentWinRate) {
                this.elements.recentWinrate.textContent = 
                    `${breakdown.recentWinRate.raw.toFixed(1)}% (${breakdown.recentWinRate.games} recent)`;
            }

            // High accuracy
            if (breakdown.accuracy) {
                this.elements.highAccuracy.textContent = 
                    `${breakdown.accuracy.highAccuracyGames}/${breakdown.accuracy.gamesWithAccuracy} (${breakdown.accuracy.raw.toFixed(1)}%)`;
            }
        }

        // Account age
        if (data.accountAge !== undefined) {
            const years = Math.floor(data.accountAge / 365);
            const months = Math.floor((data.accountAge % 365) / 30);
            
            let ageText = '';
            if (years > 0) {
                ageText = `${years}y ${months}m`;
            } else if (months > 0) {
                ageText = `${months} months`;
            } else {
                ageText = `${data.accountAge} days`;
            }
            
            if (data.accountAgeFactor && data.accountAgeFactor > 1) {
                ageText += ' ⚠️';
            }
            
            this.elements.accountAge.textContent = ageText;
        }
    }

    getRiskLevel(score) {
        if (score <= RISK_LEVELS.LOW.max) return RISK_LEVELS.LOW;
        if (score <= RISK_LEVELS.MEDIUM.max) return RISK_LEVELS.MEDIUM;
        return RISK_LEVELS.HIGH;
    }
}

// Initialize popup
document.addEventListener('DOMContentLoaded', () => {
    window.spideySensePopup = new SpideySensePopup();
});
