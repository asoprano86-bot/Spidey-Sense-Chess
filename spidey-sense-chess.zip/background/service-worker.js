/**
 * Spidey Sense Chess - Background Service Worker
 * Handles risk score calculations and communication
 */

import { gatherPlayerData } from '../utils/api-utils.js';
import { calculatePlayerMetrics } from '../utils/metrics-utils.js';
import { calculateRiskScore } from '../utils/risk-score.js';
import { DEFAULT_SETTINGS } from '../config.js';

// Global state
let currentGameState = {
    opponentUsername: null,
    currentPlayer: null,
    gameId: null,
    isSpectating: false,
    timestamp: null
};

let popupPort = null;
let lastRiskScore = null;
let settings = { ...DEFAULT_SETTINGS };

/**
 * Load settings from storage
 */
async function loadSettings() {
    try {
        const result = await chrome.storage.local.get('settings');
        if (result.settings) {
            settings = { ...DEFAULT_SETTINGS, ...result.settings };
        }
    } catch (error) {
        console.error('[SpideySense] Error loading settings:', error);
    }
}

/**
 * Log with debug check
 */
function log(level, ...args) {
    if (!settings.DEBUG_MODE && level === 'debug') return;
    
    const prefix = '[SpideySense]';
    switch (level) {
        case 'debug': console.debug(prefix, ...args); break;
        case 'info': console.info(prefix, ...args); break;
        case 'warn': console.warn(prefix, ...args); break;
        case 'error': console.error(prefix, ...args); break;
    }
}

/**
 * Calculate risk score for opponent
 * @param {string} username - Opponent username
 */
async function calculateOpponentRisk(username) {
    try {
        log('info', `🕷️ Calculating risk score for: ${username}`);
        log('info', '📡 Fetching data from Chess.com API...');
        
        // Gather player data
        const playerData = await gatherPlayerData(username, settings.RATED_ONLY);
        
        log('info', `✅ Data gathered - Account age: ${playerData.profile.joinedDate.toDateString()}`);
        log('info', `📊 Found ${playerData.recentGames.length} recent games`);
        
        // Calculate metrics
        const metrics = calculatePlayerMetrics(playerData);
        
        // Calculate risk score
        const riskScore = calculateRiskScore(metrics);
        
        // Store result
        lastRiskScore = {
            ...riskScore,
            opponentUsername: username,
            currentPlayer: currentGameState.currentPlayer
        };
        
        // Log results
        log('info', `🎯 Risk Score: ${Math.round(riskScore.maxScore.value)}% (${riskScore.riskLevel.label})`);
        
        if (riskScore.maxScore.format) {
            log('info', `📈 Highest risk format: ${riskScore.maxScore.format.replace('chess_', '')}`);
        }
        
        // Send to popup
        if (popupPort) {
            popupPort.postMessage({
                action: 'updateRiskScore',
                data: lastRiskScore
            });
        }
        
        // Update badge
        await updateBadge(riskScore);
        
        return lastRiskScore;
        
    } catch (error) {
        log('error', 'Error calculating risk score:', error);
        
        if (popupPort) {
            popupPort.postMessage({
                action: 'error',
                message: error.message || 'Failed to calculate risk score'
            });
        }
        
        throw error;
    }
}

/**
 * Update extension badge based on risk level
 * @param {Object} riskScore - Risk score result
 */
async function updateBadge(riskScore) {
    if (!settings.SHOW_BADGE) {
        await chrome.action.setBadgeText({ text: '' });
        return;
    }
    
    try {
        if (!riskScore || riskScore.maxScore.value === 0) {
            await chrome.action.setBadgeText({ text: '' });
            return;
        }
        
        const score = Math.round(riskScore.maxScore.value);
        let badgeText = score.toString();
        
        // Truncate if needed
        if (score >= 100) badgeText = '100';
        
        await chrome.action.setBadgeText({ text: badgeText });
        await chrome.action.setBadgeBackgroundColor({ 
            color: riskScore.riskLevel.color 
        });
        
        log('debug', `Badge updated: ${badgeText}% (${riskScore.riskLevel.label})`);
        
    } catch (error) {
        log('error', 'Error updating badge:', error);
    }
}

/**
 * Handle game state changes from content script
 * @param {string} updateType - Type of update
 * @param {Object} data - Update data
 */
async function handleGameStateChange(updateType, data) {
    try {
        log('debug', 'Game state change:', updateType, data);
        
        switch (updateType) {
            case 'new_game':
                // Reset state for new game
                currentGameState = {
                    opponentUsername: null,
                    currentPlayer: data.currentPlayer || null,
                    gameId: data.gameId,
                    isSpectating: false,
                    timestamp: Date.now()
                };
                lastRiskScore = null;
                
                // Clear display
                if (popupPort) {
                    popupPort.postMessage({ action: 'clearDisplay' });
                }
                await chrome.action.setBadgeText({ text: '' });
                
                log('info', `🎮 New game detected: ${data.gameId}`);
                break;
                
            case 'game_left':
                currentGameState = {
                    opponentUsername: null,
                    currentPlayer: null,
                    gameId: null,
                    isSpectating: false,
                    timestamp: null
                };
                lastRiskScore = null;
                
                if (popupPort) {
                    popupPort.postMessage({ action: 'clearDisplay' });
                }
                await chrome.action.setBadgeText({ text: '' });
                
                log('info', '👋 Game page left');
                break;
                
            case 'opponent_detected':
                currentGameState.opponentUsername = data.username;
                currentGameState.currentPlayer = data.currentPlayer || currentGameState.currentPlayer;
                currentGameState.isSpectating = data.isSpectating || false;
                currentGameState.timestamp = data.timestamp;
                
                log('info', `👤 Opponent detected: ${data.username}`);
                log('info', `🎭 Current player: ${currentGameState.currentPlayer}`);
                log('info', `👁️ Spectating: ${currentGameState.isSpectating}`);
                
                // Auto-open popup if enabled
                if (settings.AUTO_OPEN_POPUP) {
                    try {
                        await chrome.action.openPopup();
                    } catch (error) {
                        log('debug', 'Could not auto-open popup:', error);
                    }
                }
                
                // Notify popup to show loading
                if (popupPort) {
                    popupPort.postMessage({ action: 'calculatingRiskScore' });
                }
                
                // Calculate risk score
                await calculateOpponentRisk(data.username);
                break;
                
            case 'opponent_pending':
                if (popupPort) {
                    popupPort.postMessage({ 
                        action: 'opponentPending',
                        data: data
                    });
                }
                break;
                
            default:
                log('warn', 'Unknown update type:', updateType);
        }
        
    } catch (error) {
        log('error', 'Error handling game state change:', error);
    }
}

/**
 * Handle messages from content script or popup
 */
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    try {
        log('debug', 'Message received:', request);
        
        if (request.action === 'gameStateChanged') {
            handleGameStateChange(request.updateType, request.data);
            sendResponse({ success: true });
            return true;
        }
        
        if (request.action === 'getCurrentState') {
            sendResponse({
                success: true,
                state: currentGameState,
                lastRiskScore
            });
            return true;
        }
        
        sendResponse({ success: false, error: 'Unknown action' });
        return true;
        
    } catch (error) {
        log('error', 'Error handling message:', error);
        sendResponse({ success: false, error: error.message });
        return true;
    }
});

/**
 * Handle popup connections
 */
chrome.runtime.onConnect.addListener((port) => {
    if (port.name === 'popup') {
        log('debug', 'Popup connected');
        popupPort = port;
        
        // Clear badge when popup opens
        chrome.action.setBadgeText({ text: '' });
        
        // Send current state
        if (lastRiskScore) {
            port.postMessage({
                action: 'updateRiskScore',
                data: lastRiskScore
            });
        } else if (currentGameState.opponentUsername) {
            port.postMessage({ action: 'calculatingRiskScore' });
            // Recalculate if needed
            calculateOpponentRisk(currentGameState.opponentUsername);
        } else {
            port.postMessage({ action: 'clearDisplay' });
        }
        
        // Handle popup messages
        port.onMessage.addListener((msg) => {
            if (msg.action === 'getCurrentState') {
                port.postMessage({
                    action: 'updateRiskScore',
                    data: lastRiskScore
                });
            }
        });
        
        port.onDisconnect.addListener(() => {
            log('debug', 'Popup disconnected');
            popupPort = null;
        });
    }
});

/**
 * Handle extension installation
 */
chrome.runtime.onInstalled.addListener(() => {
    log('info', '🕷️ Spidey Sense Chess installed!');
    log('info', 'Protecting you from chess cheaters...');
});

// Initialize
loadSettings();
log('info', '🕷️ Spidey Sense Chess background service started');
