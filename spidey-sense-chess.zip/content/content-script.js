/**
 * Spidey Sense Chess - Content Script
 * Detects opponent username on Chess.com game pages
 * 
 * KEY IMPROVEMENTS:
 * - Uses #notifications-request for logged-in username
 * - Uses .player-component.player-bottom/top for player detection
 * - Waits for DOM stabilization before detection
 * - Validates usernames to avoid "@game" false positives
 * - Confirms bottom player matches logged-in user
 */

class SpideySenseContentScript {
    constructor() {
        this.observer = null;
        this.urlObserver = null;
        this.currentState = {
            gameId: null,
            currentPlayer: null,
            opponentUsername: null,
            isSpectating: false,
            lastCheck: 0
        };
        
        this.debounceInterval = 2000;
        this.currentUrl = window.location.href;
        
        // Get logged-in username from notifications element
        this.loggedInUsername = this.extractLoggedInUsername();
        console.log('[SpideySense] Content script initialized, logged in as:', this.loggedInUsername);
        
        this.initialize();
    }

    /**
     * Extract logged-in username from Chess.com page
     * @returns {string|null} Username or null
     */
    extractLoggedInUsername() {
        const notifRequest = document.getElementById('notifications-request');
        if (notifRequest) {
            const username = notifRequest.getAttribute('username');
            if (username && username.trim()) {
                return username.trim();
            }
        }
        return null;
    }

    /**
     * Get username from bottom player (current user's position)
     * @returns {string|null} Username or null
     */
    getBottomUsername() {
        const bottomPlayer = document.querySelector('.player-component.player-bottom');
        if (!bottomPlayer) return null;
        
        // Try multiple selectors for robustness
        const selectors = [
            '.user-username-component.user-tagline-username',
            '.user-username-component',
            '[data-username]',
            '.username'
        ];
        
        for (const selector of selectors) {
            const element = bottomPlayer.querySelector(selector);
            if (element) {
                const username = element.textContent?.trim() || element.getAttribute('data-username');
                if (username && username.trim()) {
                    return username.trim();
                }
            }
        }
        return null;
    }

    /**
     * Get username from top player (opponent's position)
     * @returns {string|null} Username or null
     */
    getTopUsername() {
        const topPlayer = document.querySelector('.player-component.player-top');
        if (!topPlayer) return null;
        
        const selectors = [
            '.user-username-component.user-tagline-username',
            '.user-username-component',
            '[data-username]',
            '.username'
        ];
        
        for (const selector of selectors) {
            const element = topPlayer.querySelector(selector);
            if (element) {
                const username = element.textContent?.trim() || element.getAttribute('data-username');
                if (username && username.trim()) {
                    return username.trim();
                }
            }
        }
        return null;
    }

    /**
     * Validate username to avoid false positives
     * @param {string} username - Username to validate
     * @returns {boolean} Whether username is valid
     */
    isValidUsername(username) {
        if (!username || typeof username !== 'string') return false;
        if (username.length < 2 || username.length > 20) return false;
        
        // Reject obvious false positives
        const invalidPatterns = [
            '@game',
            '@player',
            '@opponent',
            'game',
            'player',
            'opponent',
            'anonymous',
            'unknown',
            'guest'
        ];
        
        const lowerUsername = username.toLowerCase();
        if (invalidPatterns.some(pattern => lowerUsername.includes(pattern))) {
            console.warn('[SpideySense] Invalid username detected:', username);
            return false;
        }
        
        // Valid chess.com usernames: start with letter, contain letters/numbers/underscore/hyphen
        const usernameRegex = /^[a-zA-Z][a-zA-Z0-9_-]{1,19}$/;
        return usernameRegex.test(username);
    }

    /**
     * Wait for game to be ready (both players visible)
     * @param {number} maxWaitMs - Maximum wait time
     * @returns {Promise<boolean>} Whether game is ready
     */
    async waitForGameReady(maxWaitMs = 5000, checkInterval = 500) {
        const startTime = Date.now();
        
        while (Date.now() - startTime < maxWaitMs) {
            const bottomName = this.getBottomUsername();
            const topName = this.getTopUsername();
            
            if (bottomName && this.isValidUsername(bottomName) &&
                topName && this.isValidUsername(topName)) {
                console.log('[SpideySense] Game ready - both players detected');
                return true;
            }
            
            await new Promise(resolve => setTimeout(resolve, checkInterval));
        }
        
        console.warn('[SpideySense] Game not ready after timeout');
        return false;
    }

    /**
     * Wait for current player (bottom) to stabilize and match logged-in user
     * @param {number} maxWaitMs - Maximum wait time
     * @returns {Promise<boolean>} Whether player is stable
     */
    async waitForCurrentPlayerStability(maxWaitMs = 5000, checkInterval = 500) {
        if (!this.loggedInUsername) {
            console.warn('[SpideySense] No logged-in username, skipping stability check');
            return true; // Can't verify, proceed anyway
        }
        
        const startTime = Date.now();
        let stableCount = 0;
        const requiredStable = 2; // Need 2 consecutive matching checks
        
        while (Date.now() - startTime < maxWaitMs) {
            const bottomName = this.getBottomUsername();
            
            if (bottomName === this.loggedInUsername) {
                stableCount++;
                if (stableCount >= requiredStable) {
                    console.log('[SpideySense] Current player confirmed stable:', this.loggedInUsername);
                    return true;
                }
            } else {
                stableCount = 0;
                if (bottomName) {
                    console.log('[SpideySense] Bottom player mismatch:', bottomName, 'vs', this.loggedInUsername);
                }
            }
            
            await new Promise(resolve => setTimeout(resolve, checkInterval));
        }
        
        console.warn('[SpideySense] Could not confirm current player stability');
        return false;
    }

    /**
     * Detect current player and opponent
     */
    async detectPlayers() {
        console.log('[SpideySense] Detecting players...');
        
        // Wait for game to be ready
        await this.waitForGameReady();
        
        // Confirm current player stability
        await this.waitForCurrentPlayerStability();
        
        const bottomUsername = this.getBottomUsername();
        const topUsername = this.getTopUsername();
        
        console.log('[SpideySense] Detected - Bottom:', bottomUsername, 'Top:', topUsername);
        
        // Check if spectating
        const isSpectating = this.loggedInUsername && 
                            bottomUsername !== this.loggedInUsername && 
                            topUsername !== this.loggedInUsername;
        
        if (isSpectating) {
            console.log('[SpideySense] Spectating game');
            this.currentState.isSpectating = true;
            this.currentState.currentPlayer = bottomUsername;
            this.currentState.opponentUsername = topUsername;
            
            if (this.isValidUsername(topUsername)) {
                this.notifyBackground('opponent_detected', {
                    username: topUsername,
                    isSpectating: true
                });
            }
            return;
        }
        
        // Normal game - bottom should be current user
        if (bottomUsername === this.loggedInUsername || !this.loggedInUsername) {
            this.currentState.currentPlayer = bottomUsername || 'Unknown';
            this.currentState.isSpectating = false;
            
            // Wait a bit for opponent to stabilize
            await new Promise(resolve => setTimeout(resolve, 500));
            
            // Detect opponent with retries
            let attempts = 5;
            while (attempts > 0 && !this.currentState.opponentUsername) {
                const currentTop = this.getTopUsername();
                
                if (this.isValidUsername(currentTop) && currentTop !== this.currentState.currentPlayer) {
                    this.currentState.opponentUsername = currentTop;
                    console.log('[SpideySense] Opponent detected:', currentTop);
                    
                    this.notifyBackground('opponent_detected', {
                        username: currentTop,
                        currentPlayer: this.currentState.currentPlayer,
                        isSpectating: false
                    });
                    return;
                }
                
                console.log('[SpideySense] Opponent not ready, retrying...');
                this.notifyBackground('opponent_pending', { partial: true });
                await new Promise(resolve => setTimeout(resolve, 500));
                attempts--;
            }
            
            console.warn('[SpideySense] Failed to detect opponent after retries');
        } else {
            console.warn('[SpideySense] Bottom player does not match logged-in user');
        }
    }

    /**
     * Extract game ID from URL
     * @returns {string|null} Game ID or null
     */
    getGameIdFromUrl() {
        const match = window.location.href.match(/\/game\/live\/(\d+)/);
        return match ? match[1] : null;
    }

    /**
     * Send message to background script
     * @param {string} type - Message type
     * @param {Object} data - Message data
     */
    async notifyBackground(type, data = {}) {
        try {
            await chrome.runtime.sendMessage({
                action: 'gameStateChanged',
                updateType: type,
                data: {
                    ...data,
                    gameId: this.currentState.gameId,
                    currentPlayer: this.currentState.currentPlayer,
                    timestamp: Date.now(),
                    url: window.location.href
                }
            });
        } catch (error) {
            if (error.message.includes('Extension context invalidated')) {
                console.log('[SpideySense] Extension context invalidated, reinitializing...');
                setTimeout(() => this.initialize(), 1000);
            } else {
                console.error('[SpideySense] Error sending message:', error);
            }
        }
    }

    /**
     * Check for game changes
     */
    async checkForGameChanges() {
        const now = Date.now();
        if (now - this.currentState.lastCheck < this.debounceInterval) return;
        this.currentState.lastCheck = now;
        
        const gameId = this.getGameIdFromUrl();
        if (!gameId) return;
        
        // New game detected
        if (gameId !== this.currentState.gameId) {
            console.log('[SpideySense] New game detected:', gameId);
            this.currentState.gameId = gameId;
            this.currentState.opponentUsername = null;
            this.currentState.currentPlayer = null;
            
            this.notifyBackground('new_game', { gameId });
            
            // Wait for DOM to settle
            await new Promise(resolve => setTimeout(resolve, 1000));
            
            await this.detectPlayers();
        }
        
        // Try to detect opponent if missing
        if (!this.currentState.opponentUsername && this.currentState.gameId) {
            const currentTop = this.getTopUsername();
            if (this.isValidUsername(currentTop) && currentTop !== this.currentState.currentPlayer) {
                this.currentState.opponentUsername = currentTop;
                console.log('[SpideySense] Opponent detected on retry:', currentTop);
                this.notifyBackground('opponent_detected', {
                    username: currentTop,
                    currentPlayer: this.currentState.currentPlayer
                });
            }
        }
    }

    /**
     * Set up mutation observer for game changes
     */
    setupObserver() {
        this.observer = new MutationObserver(() => {
            this.checkForGameChanges();
        });
        
        this.observer.observe(document.body, {
            childList: true,
            subtree: true
        });
        
        // Initial check
        this.checkForGameChanges();
    }

    /**
     * Set up URL change observer
     */
    setupUrlObserver() {
        let lastUrl = window.location.href;
        
        this.urlObserver = new MutationObserver(() => {
            if (window.location.href !== lastUrl) {
                console.log('[SpideySense] URL changed:', window.location.href);
                lastUrl = window.location.href;
                this.currentUrl = lastUrl;
                
                const gameId = this.getGameIdFromUrl();
                if (this.currentState.gameId && !gameId) {
                    console.log('[SpideySense] Left game page');
                    this.notifyBackground('game_left');
                    this.currentState = {
                        gameId: null,
                        currentPlayer: null,
                        opponentUsername: null,
                        isSpectating: false,
                        lastCheck: 0
                    };
                }
            }
        });
        
        this.urlObserver.observe(document.body, {
            childList: true,
            subtree: true
        });
    }

    /**
     * Set up navigation listeners
     */
    setupNavigationListeners() {
        window.addEventListener('popstate', () => this.checkForGameChanges());
        
        const originalPushState = history.pushState;
        const originalReplaceState = history.replaceState;
        
        history.pushState = function(...args) {
            originalPushState.apply(this, args);
            this.checkForGameChanges();
        }.bind(this);
        
        history.replaceState = function(...args) {
            originalReplaceState.apply(this, args);
            this.checkForGameChanges();
        }.bind(this);
    }

    /**
     * Initialize content script
     */
    async initialize() {
        console.log('[SpideySense] Initializing content script...');
        
        const gameId = this.getGameIdFromUrl();
        if (!gameId) {
            console.log('[SpideySense] Not a game page, waiting...');
            this.setupUrlObserver();
            return;
        }
        
        console.log('[SpideySense] On game page:', gameId);
        this.currentState.gameId = gameId;
        
        // Notify background of new game
        this.notifyBackground('new_game', { gameId });
        
        // Set up observers
        this.setupUrlObserver();
        this.setupNavigationListeners();
        
        // Wait for DOM to be ready
        if (document.readyState === 'loading') {
            document.addEventListener('DOMContentLoaded', () => this.detectPlayers());
        } else {
            await this.detectPlayers();
        }
        
        // Set up game observer
        this.setupObserver();
    }

    /**
     * Cleanup observers
     */
    cleanup() {
        if (this.observer) {
            this.observer.disconnect();
            this.observer = null;
        }
        if (this.urlObserver) {
            this.urlObserver.disconnect();
            this.urlObserver = null;
        }
    }
}

// Start content script
const spideySense = new SpideySenseContentScript();

// Handle page unload
window.addEventListener('unload', () => {
    spideySense.cleanup();
});
